set(CMAKE_HOST_SYSTEM "Linux-6.1.157-android14-11-o-gb8d874e47ac6")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "6.1.157-android14-11-o-gb8d874e47ac6")
set(CMAKE_HOST_SYSTEM_PROCESSOR "aarch64")

include("/data/data/com.tom.rv2ide/files/home/android-sdk/ndk/29.0.14033849/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "aarch64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
