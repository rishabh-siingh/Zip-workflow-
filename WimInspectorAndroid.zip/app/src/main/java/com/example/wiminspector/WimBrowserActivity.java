package com.example.wiminspector;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WimBrowserActivity extends AppCompatActivity {

    private static final String ROOT = "/";
    private static final int REQUEST_EXTRACT_FILE = 4101;

    private TextView titleText;
    private TextView breadcrumbText;
    private TextView summaryText;
    private TextView emptyText;

    private ProgressBar progressBar;
    private EditText searchInput;
    private RecyclerView fileList;

    private MaterialButton rootButton;
    private MaterialButton refreshButton;

    private DirectoryAdapter adapter;

    private final List<DirectoryEntry> allEntries = new ArrayList<>();

    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    private String wimPath;
    private String imageName;
    private String currentPath = ROOT;

    private String pendingExtractPath;
    private String pendingExtractName;

    private int imageIndex;
    private boolean truncated;
    private boolean extracting;

    static {
        System.loadLibrary("wimlib_jni");
    }

    private native String nativeListDirectory(
            String path,
            int imageIndex,
            String directoryPath
    );

    private native String nativeExtractFile(
            String wimPath,
            int imageIndex,
            String imagePath,
            String destinationDirectory
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wim_browser);

        wimPath = getIntent().getStringExtra("wim_path");
        imageIndex = getIntent().getIntExtra("image_index", 0);
        imageName = getIntent().getStringExtra("image_name");

        if (wimPath == null ||
                imageIndex < 1 ||
                !new File(wimPath).isFile()) {

            Toast.makeText(
                    this,
                    "WIM image is not available.",
                    Toast.LENGTH_LONG
            ).show();

            finish();
            return;
        }

        titleText = findViewById(R.id.browserTitle);
        breadcrumbText = findViewById(R.id.browserBreadcrumb);
        summaryText = findViewById(R.id.browserSummary);
        emptyText = findViewById(R.id.browserEmpty);

        progressBar = findViewById(R.id.browserProgress);
        searchInput = findViewById(R.id.browserSearch);
        fileList = findViewById(R.id.browserFileList);

        rootButton = findViewById(R.id.browserRootButton);
        refreshButton = findViewById(R.id.browserRefreshButton);

        titleText.setText("Browse image index " + imageIndex);

        if (imageName != null && !imageName.isEmpty()) {
            titleText.setText(imageName);
        }

        summaryText.setText("Preparing image index " + imageIndex);
        breadcrumbText.setText("Image root");

        adapter = new DirectoryAdapter();

        fileList.setLayoutManager(new LinearLayoutManager(this));
        fileList.setAdapter(adapter);
        fileList.setHasFixedSize(false);

        rootButton.setOnClickListener(v -> navigateTo(ROOT));

        refreshButton.setOnClickListener(
                v -> loadDirectory(currentPath)
        );

        searchInput.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after
            ) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count
            ) {
                applyFilter(s == null ? "" : s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        loadDirectory(ROOT);
    }

    private void navigateTo(String path) {
        currentPath = normalizePath(path);

        searchInput.setText("");

        loadDirectory(currentPath);
    }

    private void navigateUp() {

        if (ROOT.equals(currentPath)) {
            return;
        }

        int lastSeparator = currentPath.lastIndexOf('/');

        if (lastSeparator <= 0) {
            navigateTo(ROOT);
        } else {
            navigateTo(
                    currentPath.substring(0, lastSeparator)
            );
        }
    }

    private String normalizePath(String path) {

        if (path == null ||
                path.trim().isEmpty() ||
                "/".equals(path.trim()) ||
                "\\".equals(path.trim())) {

            return ROOT;
        }

        String normalized = path.replace('\\', '/').trim();

        while (normalized.startsWith("/")) {
            normalized = normalized.substring(1);
        }

        while (normalized.endsWith("/")) {
            normalized = normalized.substring(
                    0,
                    normalized.length() - 1
            );
        }

        return normalized.isEmpty()
                ? ROOT
                : "/" + normalized;
    }

    private void loadDirectory(String path) {

        if (extracting) {
            return;
        }

        currentPath = normalizePath(path);

        updateBreadcrumb();

        progressBar.setVisibility(View.VISIBLE);
        fileList.setVisibility(View.GONE);
        emptyText.setVisibility(View.GONE);

        summaryText.setText("Reading directory…");

        rootButton.setEnabled(false);
        refreshButton.setEnabled(false);

        final String requestedPath = currentPath;

        executor.execute(() -> {

            String result;

            try {
                result = nativeListDirectory(
                        wimPath,
                        imageIndex,
                        requestedPath
                );

            } catch (Throwable error) {

                result = "ERROR|" + error.getMessage();
            }

            final String nativeResult = result;

            runOnUiThread(() -> {

                if (isFinishing() || isDestroyed()) {
                    return;
                }

                if (!requestedPath.equals(currentPath)) {
                    return;
                }

                progressBar.setVisibility(View.GONE);

                rootButton.setEnabled(true);
                refreshButton.setEnabled(true);

                if (nativeResult == null ||
                        nativeResult.startsWith("ERROR|")) {

                    allEntries.clear();
                    adapter.setItems(allEntries);

                    fileList.setVisibility(View.GONE);
                    emptyText.setVisibility(View.VISIBLE);

                    emptyText.setText(
                            nativeResult == null
                                    ? "Native engine returned no result."
                                    : nativeResult.substring(6)
                    );

                    summaryText.setText(
                            "Could not read this directory"
                    );

                    return;
                }

                parseEntries(nativeResult);

                applyFilter(
                        searchInput.getText().toString()
                );
            });
        });
    }

    private void parseEntries(String result) {

        allEntries.clear();
        truncated = false;

        String[] lines = result.split("\n");

        for (String line : lines) {

            if (line.isEmpty() || "EMPTY".equals(line)) {
                continue;
            }

            if (line.startsWith("TRUNCATED|")) {
                truncated = true;
                continue;
            }

            String[] parts = line.split("\\|", 5);

            if (parts.length < 5 ||
                    !"ENTRY".equals(parts[0])) {
                continue;
            }

            try {

                boolean directory = "D".equals(parts[1]);

                long size = Long.parseLong(parts[2]);

                int attributes = (int) Long.parseLong(
                        parts[3],
                        16
                );

                String name = parts[4];

                if (!name.isEmpty() &&
                        !".".equals(name) &&
                        !"..".equals(name)) {

                    allEntries.add(
                            new DirectoryEntry(
                                    directory,
                                    size,
                                    attributes,
                                    name
                            )
                    );
                }

            } catch (NumberFormatException ignored) {
                // Ignore malformed entries.
            }
        }

        Collections.sort(
                allEntries,
                new Comparator<DirectoryEntry>() {

                    @Override
                    public int compare(
                            DirectoryEntry a,
                            DirectoryEntry b
                    ) {

                        if (a.directory != b.directory) {
                            return a.directory ? -1 : 1;
                        }

                        return a.name.compareToIgnoreCase(b.name);
                    }
                }
        );
    }

    private void applyFilter(String query) {

        String needle = query == null
                ? ""
                : query.trim().toLowerCase(Locale.ROOT);

        List<DirectoryEntry> visible = new ArrayList<>();

        for (DirectoryEntry entry : allEntries) {

            if (needle.isEmpty() ||
                    entry.name.toLowerCase(Locale.ROOT)
                            .contains(needle)) {

                visible.add(entry);
            }
        }

        // Parent directory row.
        if (!ROOT.equals(currentPath) &&
                (needle.isEmpty() || "..".contains(needle))) {

            visible.add(
                    0,
                    new DirectoryEntry(
                            true,
                            0,
                            0,
                            ".."
                    )
            );
        }

        adapter.setItems(visible);

        int folders = 0;
        int files = 0;

        for (DirectoryEntry entry : allEntries) {

            if (entry.directory) {
                folders++;
            } else {
                files++;
            }
        }

        String summary =
                allEntries.size() + " items  •  " +
                folders + " folders  •  " +
                files + " files";

        if (truncated) {
            summary += "  •  list capped";
        }

        if (!needle.isEmpty()) {
            summary += "  •  " + visible.size() + " matches";
        }

        summaryText.setText(summary);

        if (visible.isEmpty()) {

            fileList.setVisibility(View.GONE);
            emptyText.setVisibility(View.VISIBLE);

            emptyText.setText(
                    needle.isEmpty()
                            ? "This folder is empty."
                            : "No matching files or folders."
            );

        } else {

            emptyText.setVisibility(View.GONE);
            fileList.setVisibility(View.VISIBLE);
        }
    }

    private void updateBreadcrumb() {

        String display = ROOT.equals(currentPath)
                ? "Image root"
                : "Image root  /  " +
                  currentPath.substring(1).replace("/", "  /  ");

        breadcrumbText.setText(display);
    }

    private void openEntry(DirectoryEntry entry) {

        if ("..".equals(entry.name)) {
            navigateUp();
            return;
        }

        String fullPath = ROOT.equals(currentPath)
                ? ROOT + entry.name
                : currentPath + "/" + entry.name;

        if (entry.directory) {

            navigateTo(fullPath);

        } else {

            String details =
                    "File: " + entry.name +
                    "\n\nPath: " + fullPath +
                    "\n\nSize: " + formatSize(entry.size) +
                    "\nAttributes: 0x" +
                    String.format(
                            Locale.ROOT,
                            "%08X",
                            entry.attributes
                    ) +
                    attributeDescription(entry.attributes);

            new AlertDialog.Builder(this)
                    .setTitle("File information")
                    .setMessage(details)
                    .setNegativeButton("Close", null)
                    .setPositiveButton(
                            "Extract",
                            (dialog, which) -> {

                                pendingExtractPath = fullPath;
                                pendingExtractName = entry.name;

                                launchExtractPicker();
                            }
                    )
                    .show();
        }
    }

    private void launchExtractPicker() {

        if (pendingExtractPath == null ||
                pendingExtractName == null) {

            Toast.makeText(
                    this,
                    "No file selected.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Intent intent = new Intent(
                Intent.ACTION_CREATE_DOCUMENT
        );

        intent.addCategory(Intent.CATEGORY_OPENABLE);

        intent.setType("application/octet-stream");

        intent.putExtra(
                Intent.EXTRA_TITLE,
                pendingExtractName
        );

        startActivityForResult(
                intent,
                REQUEST_EXTRACT_FILE
        );
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode != REQUEST_EXTRACT_FILE) {
            return;
        }

        if (resultCode != RESULT_OK ||
                data == null ||
                data.getData() == null) {

            pendingExtractPath = null;
            pendingExtractName = null;

            return;
        }

        Uri destinationUri = data.getData();

        String imagePath = pendingExtractPath;
        String fileName = pendingExtractName;

        if (imagePath == null || fileName == null) {
            return;
        }

        pendingExtractPath = null;
        pendingExtractName = null;

        extractFile(imagePath, fileName, destinationUri);
    }

    private void extractFile(
            String imagePath,
            String fileName,
            Uri destinationUri
    ) {

        if (extracting) {
            return;
        }

        // Only accept a single filename, never a path.
        if (fileName.contains("/") ||
                fileName.contains("\\") ||
                ".".equals(fileName) ||
                "..".equals(fileName)) {

            Toast.makeText(
                    this,
                    "Invalid file name.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        extracting = true;

        progressBar.setVisibility(View.VISIBLE);
        fileList.setVisibility(View.GONE);

        rootButton.setEnabled(false);
        refreshButton.setEnabled(false);

        summaryText.setText(
                "Extracting " + fileName + "…"
        );

        final String selectedImagePath = imagePath;
        final String selectedFileName = fileName;
        final Uri selectedDestination = destinationUri;

        executor.execute(() -> {

            File tempDirectory = new File(
                    getCacheDir(),
                    "wim_extract_" + System.currentTimeMillis()
            );

            try {

                if (!tempDirectory.mkdirs()) {
                    throw new Exception(
                            "Cannot create temporary directory."
                    );
                }

                String nativeResult = nativeExtractFile(
                        wimPath,
                        imageIndex,
                        selectedImagePath,
                        tempDirectory.getAbsolutePath()
                );

                if (nativeResult == null ||
                        !"OK".equals(nativeResult)) {

                    throw new Exception(
                            nativeResult == null
                                    ? "Native extraction returned no result."
                                    : nativeResult.replace("ERROR|", "")
                    );
                }

                File extractedFile = new File(
                        tempDirectory,
                        selectedFileName
                );

                if (!extractedFile.isFile()) {
                    throw new Exception(
                            "Extracted file was not found."
                    );
                }

                try (
                        InputStream input =
                                new FileInputStream(extractedFile);

                        OutputStream output =
                                getContentResolver().openOutputStream(
                                        selectedDestination,
                                        "w"
                                )
                ) {

                    if (output == null) {
                        throw new Exception(
                                "Cannot open selected destination."
                        );
                    }

                    byte[] buffer = new byte[128 * 1024];

                    int count;

                    while ((count = input.read(buffer)) != -1) {
                        output.write(buffer, 0, count);
                    }

                    output.flush();
                }

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    extracting = false;

                    progressBar.setVisibility(View.GONE);

                    rootButton.setEnabled(true);
                    refreshButton.setEnabled(true);

                    summaryText.setText(
                            "File extracted successfully."
                    );

                    fileList.setVisibility(View.VISIBLE);

                    Toast.makeText(
                            this,
                            "Extraction completed.",
                            Toast.LENGTH_LONG
                    ).show();
                });

            } catch (Exception error) {

                final String errorMessage =
                        error.getMessage() == null
                                ? "Unknown extraction error."
                                : error.getMessage();

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    extracting = false;

                    progressBar.setVisibility(View.GONE);

                    rootButton.setEnabled(true);
                    refreshButton.setEnabled(true);

                    summaryText.setText("Extraction failed.");

                    applyFilter(
                            searchInput.getText().toString()
                    );

                    new AlertDialog.Builder(this)
                            .setTitle("Extraction failed")
                            .setMessage(errorMessage)
                            .setPositiveButton("OK", null)
                            .show();
                });

            } finally {

                deleteRecursively(tempDirectory);
            }
        });
    }

    private void deleteRecursively(File file) {

        if (file == null || !file.exists()) {
            return;
        }

        if (file.isDirectory()) {

            File[] children = file.listFiles();

            if (children != null) {
                for (File child : children) {
                    deleteRecursively(child);
                }
            }
        }

        file.delete();
    }

    private String attributeDescription(int attributes) {

        StringBuilder value = new StringBuilder();

        if ((attributes & 0x2) != 0) {
            value.append("\nHidden");
        }

        if ((attributes & 0x4) != 0) {
            value.append("\nSystem");
        }

        if ((attributes & 0x1) != 0) {
            value.append("\nRead-only");
        }

        if ((attributes & 0x400) != 0) {
            value.append("\nReparse point");
        }

        if ((attributes & 0x20) != 0) {
            value.append("\nArchive");
        }

        return value.toString();
    }

    private String formatSize(long bytes) {

        if (bytes < 1024) {
            return bytes + " B";
        }

        double value = bytes;

        String[] units = {
                "KB",
                "MB",
                "GB",
                "TB"
        };

        int unit = -1;

        do {
            value /= 1024.0;
            unit++;

        } while (
                value >= 1024 &&
                unit < units.length - 1
        );

        return String.format(
                Locale.getDefault(),
                "%.2f %s",
                value,
                units[unit]
        );
    }

    @Override
    protected void onDestroy() {

        executor.shutdownNow();

        super.onDestroy();
    }

    private static class DirectoryEntry {

        final boolean directory;
        final long size;
        final int attributes;
        final String name;

        DirectoryEntry(
                boolean directory,
                long size,
                int attributes,
                String name
        ) {

            this.directory = directory;
            this.size = size;
            this.attributes = attributes;
            this.name = name;
        }
    }

    private class DirectoryAdapter
            extends RecyclerView.Adapter<DirectoryAdapter.EntryHolder> {

        private final List<DirectoryEntry> items =
                new ArrayList<>();

        void setItems(List<DirectoryEntry> entries) {

            items.clear();
            items.addAll(entries);

            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public EntryHolder onCreateViewHolder(
                @NonNull ViewGroup parent,
                int viewType
        ) {

            LinearLayout row = new LinearLayout(
                    WimBrowserActivity.this
            );

            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            row.setPadding(
                    dp(14),
                    dp(10),
                    dp(14),
                    dp(10)
            );

            row.setMinimumHeight(dp(68));

            row.setBackgroundResource(
                    android.R.drawable.list_selector_background
            );

            TextView icon = new TextView(
                    WimBrowserActivity.this
            );

            icon.setTextSize(25);
            icon.setGravity(Gravity.CENTER);

            LinearLayout.LayoutParams iconParams =
                    new LinearLayout.LayoutParams(
                            dp(42),
                            dp(44)
                    );

            row.addView(icon, iconParams);

            LinearLayout textColumn = new LinearLayout(
                    WimBrowserActivity.this
            );

            textColumn.setOrientation(
                    LinearLayout.VERTICAL
            );

            LinearLayout.LayoutParams textParams =
                    new LinearLayout.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            1
                    );

            textParams.leftMargin = dp(10);

            row.addView(textColumn, textParams);

            TextView name = new TextView(
                    WimBrowserActivity.this
            );

            name.setTextSize(15);

            name.setTextColor(
                    com.google.android.material.color.MaterialColors.getColor(
                            row,
                            com.google.android.material.R.attr.colorOnSurface
                    )
            );

            name.setMaxLines(2);

            textColumn.addView(name);

            TextView details = new TextView(
                    WimBrowserActivity.this
            );

            details.setTextSize(12);

            details.setTextColor(
                    com.google.android.material.color.MaterialColors.getColor(
                            row,
                            com.google.android.material.R.attr.colorOnSurfaceVariant
                    )
            );

            LinearLayout.LayoutParams detailParams =
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                    );

            detailParams.topMargin = dp(3);

            textColumn.addView(
                    details,
                    detailParams
            );

            return new EntryHolder(
                    row,
                    icon,
                    name,
                    details
            );
        }

        @Override
        public void onBindViewHolder(
                @NonNull EntryHolder holder,
                int position
        ) {

            DirectoryEntry entry = items.get(position);

            holder.icon.setText(
                    entry.directory ? "📁" : "📄"
            );

            holder.name.setText(entry.name);

            String detail = entry.directory
                    ? ("..".equals(entry.name)
                        ? "Parent directory"
                        : "Folder")
                    : "File  •  " + formatSize(entry.size);

            if ((entry.attributes & 0x2) != 0) {
                detail += "  •  Hidden";
            }

            if ((entry.attributes & 0x4) != 0) {
                detail += "  •  System";
            }

            if ((entry.attributes & 0x400) != 0) {
                detail += "  •  Reparse point";
            }

            holder.details.setText(detail);

            // No trailing arrow for folders.
            holder.itemView.setOnClickListener(
                    v -> openEntry(entry)
            );
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class EntryHolder extends RecyclerView.ViewHolder {

            final TextView icon;
            final TextView name;
            final TextView details;

            EntryHolder(
                    @NonNull View itemView,
                    TextView icon,
                    TextView name,
                    TextView details
            ) {

                super(itemView);

                this.icon = icon;
                this.name = name;
                this.details = details;
            }
        }
    }

    private int dp(int value) {

        return Math.round(
                value * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }
}
