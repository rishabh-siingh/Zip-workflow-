package com.example.wiminspector;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TextView fileName, fileDetails;
    private TextView engineStatus, inspectionMessage, imageDetails;

    private MaterialButton inspectButton;
    private MaterialButton browseButton;
    private Spinner imageSelector;

    private Uri selectedUri;
    private String selectedName = "";
    private File cachedImage;

    private boolean nativeLoaded = false;

    private final List<ImageEntry> images = new ArrayList<>();

    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    private native String nativeGetWimInfo(String path);

    private native String nativeGetImageDetails(
            String path,
            int imageIndex
    );

    private static class ImageEntry {
        final int index;
        final String name;
        final String description;

        ImageEntry(int index, String name, String description) {
            this.index = index;
            this.name = name;
            this.description = description;
        }
    }

    private final ActivityResultLauncher<String[]> openImage =
            registerForActivityResult(
                    new ActivityResultContracts.OpenDocument(),
                    this::onImagePicked
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fileName = findViewById(R.id.fileName);
        fileDetails = findViewById(R.id.fileDetails);

        engineStatus = findViewById(R.id.engineStatus);
        inspectionMessage = findViewById(R.id.inspectionMessage);
        imageDetails = findViewById(R.id.imageDetails);

        inspectButton = findViewById(R.id.inspectButton);
        browseButton = findViewById(R.id.browseButton);
        imageSelector = findViewById(R.id.imageSelector);

        MaterialButton chooseButton =
                findViewById(R.id.chooseButton);

        inspectButton.setEnabled(false);
        browseButton.setEnabled(false);

        try {
            System.loadLibrary("wimlib_jni");
            nativeLoaded = true;

            engineStatus.setText(
                    "Native WIM engine: loaded (wimlib 1.14.5)"
            );

            inspectionMessage.setText(
                    "Select a WIM or ESD image to inspect."
            );

        } catch (UnsatisfiedLinkError e) {
            nativeLoaded = false;

            engineStatus.setText(
                    "Native WIM engine: failed to load"
            );

            inspectionMessage.setText(e.toString());
        }

        chooseButton.setOnClickListener(v ->
                openImage.launch(new String[]{"*/*"})
        );

        inspectButton.setOnClickListener(v ->
                inspectSelectedImage()
        );

        browseButton.setOnClickListener(v ->
                launchWimBrowser()
        );

        imageSelector.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        if (position >= 0 &&
                                position < images.size()) {

                            showImageDetails(images.get(position));
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent) {
                    }
                }
        );
    }

    private void onImagePicked(Uri uri) {

        if (uri == null) return;

        String name = queryDisplayName(uri);
        String lower = name.toLowerCase(Locale.ROOT);

        boolean supported =
                lower.endsWith(".wim")
                        || lower.endsWith(".esd")
                        || lower.endsWith(".swm");

        if (!supported) {
            Toast.makeText(
                    this,
                    "Choose a .wim, .esd or .swm file.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        selectedUri = uri;
        selectedName = name;

        if (cachedImage != null) {
            cachedImage.delete();
            cachedImage = null;
        }

        images.clear();

        imageSelector.setAdapter(null);
        imageDetails.setText("No image details available.");

        long size = querySize(uri);

        fileName.setText(name);

        fileDetails.setText(
                size >= 0
                        ? formatSize(size) + " • Access granted"
                        : "Size unavailable • Access granted"
        );

        boolean isSwm = lower.endsWith(".swm");

        inspectionMessage.setText(
                isSwm
                        ? "Split SWM inspection is not implemented yet."
                        : "Image selected. Ready for inspection."
        );

        inspectButton.setEnabled(nativeLoaded && !isSwm);
        inspectButton.setText("Inspect image");

        browseButton.setEnabled(false);
    }

    private void inspectSelectedImage() {

        if (selectedUri == null || !nativeLoaded) {
            return;
        }

        final boolean loadMetadata = images.isEmpty();
        final int selectedIndex;

        if (!loadMetadata) {

            int position =
                    imageSelector.getSelectedItemPosition();

            if (position < 0 || position >= images.size()) {

                Toast.makeText(
                        this,
                        "Select a valid image index.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            selectedIndex = images.get(position).index;

        } else {
            selectedIndex = 0;
        }

        inspectButton.setEnabled(false);

        inspectionMessage.setText(
                loadMetadata
                        ? "Opening WIM and reading image indexes..."
                        : "Inspecting image index " + selectedIndex + "..."
        );

        final Uri uri = selectedUri;

        executor.execute(() -> {

            File tempFile = null;

            try {

                File imageFile = cachedImage;

                if (imageFile == null || !imageFile.exists()) {

                    long expectedSize = querySize(uri);

                    StatFs stat = new StatFs(
                            getCacheDir().getAbsolutePath()
                    );

                    long available = stat.getAvailableBytes();

                    if (expectedSize > 0 &&
                            expectedSize + 32L * 1024 * 1024 > available) {

                        throw new Exception(
                                "Not enough cache storage. Required: "
                                        + formatSize(expectedSize)
                        );
                    }

                    tempFile = File.createTempFile(
                            "wim_inspect_",
                            ".wim",
                            getCacheDir()
                    );

                    try (
                            InputStream input =
                                    getContentResolver().openInputStream(uri);

                            FileOutputStream output =
                                    new FileOutputStream(tempFile)
                    ) {

                        if (input == null) {
                            throw new Exception(
                                    "Cannot open selected image."
                            );
                        }

                        byte[] buffer = new byte[1024 * 1024];
                        int count;

                        while ((count = input.read(buffer)) != -1) {
                            output.write(buffer, 0, count);
                        }

                        output.flush();
                    }

                    imageFile = tempFile;
                }

                final File completedFile = imageFile;
                final File temporaryFile = tempFile;

                final String result;

                if (loadMetadata) {

                    result = nativeGetWimInfo(
                            completedFile.getAbsolutePath()
                    );

                } else {

                    result = nativeGetImageDetails(
                            completedFile.getAbsolutePath(),
                            selectedIndex
                    );
                }

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {

                        if (temporaryFile != null) {
                            temporaryFile.delete();
                        }

                        return;
                    }

                    if (loadMetadata) {

                        if (result == null ||
                                result.startsWith("ERROR:")) {

                            inspectionMessage.setText(
                                    result == null
                                            ? "Native engine returned no result."
                                            : result
                            );

                            if (completedFile != cachedImage) {
                                completedFile.delete();
                            }

                            inspectButton.setEnabled(true);
                            return;
                        }

                        if (cachedImage != null &&
                                !cachedImage.equals(completedFile)) {

                            cachedImage.delete();
                        }

                        cachedImage = completedFile;

                        parseInspectionResult(result);

                        inspectButton.setText(
                                "Inspect selected image"
                        );

                        inspectButton.setEnabled(!images.isEmpty());

                        browseButton.setEnabled(
                                cachedImage != null && !images.isEmpty()
                        );

                    } else {

                        if (result == null ||
                                result.startsWith("ERROR:")) {

                            imageDetails.setText(
                                    result == null
                                            ? "Native engine returned no result."
                                            : result
                            );

                            inspectionMessage.setText(
                                    "Selected image inspection failed."
                            );

                        } else {

                            imageDetails.setText(result);

                            inspectionMessage.setText(
                                    "Image index " + selectedIndex
                                            + " inspected successfully."
                            );
                        }

                        inspectButton.setEnabled(true);
                    }
                });

            } catch (Exception e) {

                if (tempFile != null) {
                    tempFile.delete();
                }

                final String errorMessage =
                        e.getMessage() == null
                                ? e.toString()
                                : e.getMessage();

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    inspectionMessage.setText(
                            "Inspection failed:\n" + errorMessage
                    );

                    inspectButton.setEnabled(
                            nativeLoaded && selectedUri != null
                    );
                });
            }
        });
    }

    private void launchWimBrowser() {

        if (cachedImage == null ||
                !cachedImage.isFile() ||
                images.isEmpty()) {

            Toast.makeText(
                    this,
                    "Inspect a WIM image first.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int position =
                imageSelector.getSelectedItemPosition();

        if (position < 0 || position >= images.size()) {

            Toast.makeText(
                    this,
                    "Select a valid image index.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        ImageEntry selected = images.get(position);

        Intent intent = new Intent(
                this,
                WimBrowserActivity.class
        );

        intent.putExtra(
                "wim_path",
                cachedImage.getAbsolutePath()
        );

        intent.putExtra(
                "image_index",
                selected.index
        );

        intent.putExtra(
                "image_name",
                selected.name
        );

        startActivity(intent);
    }

    private void parseInspectionResult(String result) {

        if (result == null || result.startsWith("ERROR:")) {

            inspectionMessage.setText(
                    result == null
                            ? "Native engine returned no result."
                            : result
            );

            imageDetails.setText(
                    "Image metadata unavailable."
            );

            return;
        }

        String[] lines = result.split("\n");

        int imageCount = 0;
        int bootIndex = 0;
        int wimVersion = 0;
        int compression = 0;

        images.clear();

        for (String line : lines) {

            String[] parts = line.split("\\|", 5);

            if (parts.length == 0) continue;

            if ("WIM".equals(parts[0]) && parts.length >= 5) {

                try {
                    imageCount = Integer.parseInt(parts[1]);
                    bootIndex = Integer.parseInt(parts[2]);
                    wimVersion = Integer.parseInt(parts[3]);
                    compression = Integer.parseInt(parts[4]);

                } catch (NumberFormatException ignored) {
                }
            }

            if ("IMAGE".equals(parts[0]) && parts.length >= 4) {

                try {

                    int index = Integer.parseInt(parts[1]);

                    images.add(
                            new ImageEntry(
                                    index,
                                    parts[2],
                                    parts[3]
                            )
                    );

                } catch (NumberFormatException ignored) {
                }
            }
        }

        if (imageCount == 0) {

            inspectionMessage.setText(result);

            imageDetails.setText(
                    "No image metadata found."
            );

            return;
        }

        String summary =
                "WIM opened successfully\n"
                        + "Image count: " + imageCount + "\n"
                        + "Boot index: " + bootIndex + "\n"
                        + "WIM version: " + wimVersion + "\n"
                        + "Compression type: " + compression;

        inspectionMessage.setText(summary);

        if (images.isEmpty()) {

            imageDetails.setText(
                    "Image names could not be retrieved."
            );

            return;
        }

        List<String> labels = new ArrayList<>();

        for (ImageEntry entry : images) {

            String label =
                    "Index " + entry.index + " — "
                            + (entry.name.isEmpty()
                            ? "Unnamed image"
                            : entry.name);

            if (entry.index == bootIndex) {
                label += " (Boot)";
            }

            labels.add(label);
        }

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        labels
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        imageSelector.setAdapter(adapter);

        showImageDetails(images.get(0));
    }

    private void showImageDetails(ImageEntry entry) {

        if (entry == null) return;

        String details =
                "Image index: " + entry.index + "\n"
                        + "Image name: "
                        + (entry.name.isEmpty()
                        ? "Not specified"
                        : entry.name)
                        + "\n\nDescription:\n"
                        + (entry.description.isEmpty()
                        ? "No description available."
                        : entry.description);

        imageDetails.setText(details);
    }

    private String queryDisplayName(Uri uri) {

        try (
                Cursor cursor = getContentResolver().query(
                        uri,
                        null,
                        null,
                        null,
                        null
                )
        ) {

            if (cursor != null && cursor.moveToFirst()) {

                int index = cursor.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                );

                if (index >= 0) {
                    return cursor.getString(index);
                }
            }

        } catch (Exception ignored) {
        }

        return uri.getLastPathSegment() == null
                ? "Selected image"
                : uri.getLastPathSegment();
    }

    private long querySize(Uri uri) {

        try (
                Cursor cursor = getContentResolver().query(
                        uri,
                        new String[]{OpenableColumns.SIZE},
                        null,
                        null,
                        null
                )
        ) {

            if (cursor != null && cursor.moveToFirst()) {

                int index = cursor.getColumnIndex(
                        OpenableColumns.SIZE
                );

                if (index >= 0 && !cursor.isNull(index)) {
                    return cursor.getLong(index);
                }
            }

        } catch (Exception ignored) {
        }

        return -1;
    }

    private String formatSize(long bytes) {

        if (bytes < 1024) {
            return bytes + " B";
        }

        double value = bytes;

        String[] units = {
                "KB",
                "MB",
                "GB",
                "TB"
        };

        int unit = -1;

        do {
            value /= 1024.0;
            unit++;

        } while (
                value >= 1024 &&
                        unit < units.length - 1
        );

        return String.format(
                Locale.getDefault(),
                "%.2f %s",
                value,
                units[unit]
        );
    }

    @Override
    protected void onDestroy() {

        executor.shutdownNow();

        if (cachedImage != null) {
            cachedImage.delete();
            cachedImage = null;
        }

        super.onDestroy();
    }
}
