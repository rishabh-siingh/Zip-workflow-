cmake_minimum_required(VERSION 3.22.1)

project(wimlib_android C)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)

set(WIMLIB_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party/wimlib")

include(CheckIncludeFile)
include(CheckSymbolExists)
include(CheckStructHasMember)

check_include_file("alloca.h" HAVE_ALLOCA_H)
check_include_file("glob.h" HAVE_GLOB_H)
if(ANDROID AND CMAKE_SYSTEM_VERSION VERSION_LESS 28)
    set(HAVE_ANDROID_GLOB OFF)
else()
    set(HAVE_ANDROID_GLOB ON)
endif()
check_include_file("sys/endian.h" HAVE_SYS_ENDIAN_H)
check_include_file("sys/syscall.h" HAVE_SYS_SYSCALL_H)
check_include_file("sys/sysctl.h" HAVE_SYS_SYSCTL_H)
check_include_file("time.h" HAVE_TIME_H)
check_include_file("utime.h" HAVE_UTIME_H)

check_symbol_exists(futimens "sys/stat.h" HAVE_FUTIMENS)
check_symbol_exists(utimensat "sys/stat.h" HAVE_UTIMENSAT)
check_symbol_exists(flock "sys/file.h" HAVE_FLOCK)
check_symbol_exists(mempcpy "string.h" HAVE_MEMPCPY)
check_symbol_exists(openat "fcntl.h" HAVE_OPENAT)
check_symbol_exists(fstatat "sys/stat.h" HAVE_FSTATAT)
check_symbol_exists(readlinkat "unistd.h" HAVE_READLINKAT)
check_symbol_exists(fdopendir "dirent.h" HAVE_FDOPENDIR)
check_symbol_exists(posix_fallocate "fcntl.h" HAVE_POSIX_FALLOCATE)
check_symbol_exists(llistxattr "sys/xattr.h" HAVE_LLISTXATTR)
check_symbol_exists(lgetxattr "sys/xattr.h" HAVE_LGETXATTR)
check_symbol_exists(fsetxattr "sys/xattr.h" HAVE_FSETXATTR)
check_symbol_exists(lsetxattr "sys/xattr.h" HAVE_LSETXATTR)
check_symbol_exists(getopt_long_only "getopt.h" HAVE_GETOPT_LONG_ONLY)

check_struct_has_member(
    "struct stat" st_mtim "sys/stat.h"
    HAVE_STAT_NANOSECOND_PRECISION
)

file(MAKE_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/generated")
configure_file(
    "${CMAKE_CURRENT_SOURCE_DIR}/config.h.in"
    "${CMAKE_CURRENT_BINARY_DIR}/generated/config.h"
)

set(WIMLIB_SOURCES
    ${WIMLIB_DIR}/src/add_image.c
    ${WIMLIB_DIR}/src/avl_tree.c
    ${WIMLIB_DIR}/src/blob_table.c
    ${WIMLIB_DIR}/src/compress.c
    ${WIMLIB_DIR}/src/compress_common.c
    ${WIMLIB_DIR}/src/compress_parallel.c
    ${WIMLIB_DIR}/src/compress_serial.c
    ${WIMLIB_DIR}/src/cpu_features.c
    ${WIMLIB_DIR}/src/decompress.c
    ${WIMLIB_DIR}/src/decompress_common.c
    ${WIMLIB_DIR}/src/delete_image.c
    ${WIMLIB_DIR}/src/dentry.c
    ${WIMLIB_DIR}/src/divsufsort.c
    ${WIMLIB_DIR}/src/encoding.c
    ${WIMLIB_DIR}/src/error.c
    ${WIMLIB_DIR}/src/export_image.c
    ${WIMLIB_DIR}/src/extract.c
    ${WIMLIB_DIR}/src/file_io.c
    ${WIMLIB_DIR}/src/header.c
    ${WIMLIB_DIR}/src/inode.c
    ${WIMLIB_DIR}/src/inode_fixup.c
    ${WIMLIB_DIR}/src/inode_table.c
    ${WIMLIB_DIR}/src/integrity.c
    ${WIMLIB_DIR}/src/iterate_dir.c
    ${WIMLIB_DIR}/src/join.c
    ${WIMLIB_DIR}/src/lcpit_matchfinder.c
    ${WIMLIB_DIR}/src/lzms_common.c
    ${WIMLIB_DIR}/src/lzms_compress.c
    ${WIMLIB_DIR}/src/lzms_decompress.c
    ${WIMLIB_DIR}/src/lzx_common.c
    ${WIMLIB_DIR}/src/lzx_compress.c
    ${WIMLIB_DIR}/src/lzx_decompress.c
    ${WIMLIB_DIR}/src/metadata_resource.c
    ${WIMLIB_DIR}/src/mount_image.c
    ${WIMLIB_DIR}/src/pathlist.c
    ${WIMLIB_DIR}/src/paths.c
    ${WIMLIB_DIR}/src/pattern.c
    ${WIMLIB_DIR}/src/progress.c
    ${WIMLIB_DIR}/src/reference.c
    ${WIMLIB_DIR}/src/registry.c
    ${WIMLIB_DIR}/src/reparse.c
    ${WIMLIB_DIR}/src/resource.c
    ${WIMLIB_DIR}/src/scan.c
    ${WIMLIB_DIR}/src/security.c
    ${WIMLIB_DIR}/src/sha1.c
    ${WIMLIB_DIR}/src/solid.c
    ${WIMLIB_DIR}/src/split.c
    ${WIMLIB_DIR}/src/tagged_items.c
    ${WIMLIB_DIR}/src/template.c
    ${WIMLIB_DIR}/src/textfile.c
    ${WIMLIB_DIR}/src/threads.c
    ${WIMLIB_DIR}/src/timestamp.c
    ${WIMLIB_DIR}/src/update_image.c
    ${WIMLIB_DIR}/src/util.c
    ${WIMLIB_DIR}/src/verify.c
    ${WIMLIB_DIR}/src/wim.c
    ${WIMLIB_DIR}/src/write.c
    ${WIMLIB_DIR}/src/xml.c
    ${WIMLIB_DIR}/src/xml_windows.c
    ${WIMLIB_DIR}/src/xmlproc.c
    ${WIMLIB_DIR}/src/xpress_compress.c
    ${WIMLIB_DIR}/src/xpress_decompress.c
    ${WIMLIB_DIR}/src/unix_apply.c
    ${WIMLIB_DIR}/src/unix_capture.c
)

add_library(wimlib_jni SHARED
    ${WIMLIB_SOURCES}
    jni_bridge.c
)

target_include_directories(wimlib_jni PRIVATE
    ${WIMLIB_DIR}/include
    ${WIMLIB_DIR}/src
    ${CMAKE_CURRENT_BINARY_DIR}/generated
)

target_compile_definitions(wimlib_jni PRIVATE
    BUILDING_WIMLIB
    PACKAGE_VERSION="1.14.5"
    HAVE_CONFIG_H
)

find_package(Threads REQUIRED)

target_link_libraries(wimlib_jni
    PRIVATE
    Threads::Threads
    log
)
