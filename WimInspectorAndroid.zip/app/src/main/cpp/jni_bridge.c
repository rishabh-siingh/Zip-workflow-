#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wimlib.h"

static void copy_safe_field(char *dest, size_t capacity,
                            const char *source)
{
    if (capacity == 0)
        return;

    size_t i = 0;

    if (source != NULL) {
        while (source[i] != '\0' && i < capacity - 1) {
            char c = source[i];

            dest[i] = (c == '|' || c == '\n' ||
                       c == '\r' || c == '\t') ? ' ' : c;
            i++;
        }
    }

    dest[i] = '\0';
}

JNIEXPORT jstring JNICALL
Java_com_example_wiminspector_MainActivity_nativeGetWimInfo(
        JNIEnv *env,
        jobject thiz,
        jstring javaPath)
{
    (void)thiz;

    if (javaPath == NULL)
        return (*env)->NewStringUTF(env, "ERROR: Empty WIM path");

    const char *path =
            (*env)->GetStringUTFChars(env, javaPath, NULL);

    if (path == NULL)
        return (*env)->NewStringUTF(env, "ERROR: Cannot read file path");

    WIMStruct *wim = NULL;
    int ret = wimlib_open_wim(path, 0, &wim);

    (*env)->ReleaseStringUTFChars(env, javaPath, path);

    if (ret != 0) {
        char message[256];
        snprintf(message, sizeof(message),
                 "ERROR: wimlib_open_wim failed (code %d)", ret);
        return (*env)->NewStringUTF(env, message);
    }

    struct wimlib_wim_info info;

    ret = wimlib_get_wim_info(wim, &info);

    if (ret != 0) {
        char message[256];
        snprintf(message, sizeof(message),
                 "ERROR: wimlib_get_wim_info failed (code %d)", ret);
        wimlib_free(wim);
        return (*env)->NewStringUTF(env, message);
    }

    char result[32768];
    size_t used = 0;

    int written = snprintf(
            result, sizeof(result),
            "WIM|%u|%u|%u|%u\n",
            info.image_count,
            info.boot_index,
            info.wim_version,
            info.compression_type
    );

    if (written < 0 || (size_t)written >= sizeof(result)) {
        wimlib_free(wim);
        return (*env)->NewStringUTF(env, "ERROR: Result buffer overflow");
    }

    used = (size_t)written;

    for (int i = 1; i <= (int)info.image_count; i++) {

        const char *rawName = wimlib_get_image_name(wim, i);
        const char *rawDescription =
                wimlib_get_image_description(wim, i);

        char name[512];
        char description[1024];

        copy_safe_field(name, sizeof(name), rawName);
        copy_safe_field(description, sizeof(description), rawDescription);

        size_t remaining = sizeof(result) - used;

        written = snprintf(
                result + used,
                remaining,
                "IMAGE|%d|%s|%s\n",
                i,
                name,
                description
        );

        if (written < 0 || (size_t)written >= remaining) {
            const char *notice = "INFO|Additional image details truncated\n";
            size_t noticeLength = strlen(notice);

            if (noticeLength < remaining)
                memcpy(result + used, notice, noticeLength + 1);
            break;
        }

        used += (size_t)written;
    }

    wimlib_free(wim);

    return (*env)->NewStringUTF(env, result);
}

JNIEXPORT jstring JNICALL
Java_com_example_wiminspector_MainActivity_nativeGetImageDetails(
        JNIEnv *env,
        jobject thiz,
        jstring javaPath,
        jint imageIndex)
{
    (void)thiz;

    if (javaPath == NULL || imageIndex < 1)
        return (*env)->NewStringUTF(env, "ERROR: Invalid image selection");

    const char *path =
            (*env)->GetStringUTFChars(env, javaPath, NULL);

    if (path == NULL)
        return (*env)->NewStringUTF(env, "ERROR: Cannot read file path");

    WIMStruct *wim = NULL;
    int ret = wimlib_open_wim(path, 0, &wim);

    (*env)->ReleaseStringUTFChars(env, javaPath, path);

    if (ret != 0) {
        char message[256];
        snprintf(message, sizeof(message),
                 "ERROR: Cannot open WIM (code %d)", ret);
        return (*env)->NewStringUTF(env, message);
    }

    struct wimlib_wim_info info;
    ret = wimlib_get_wim_info(wim, &info);

    if (ret != 0 || imageIndex > (jint)info.image_count) {
        wimlib_free(wim);
        return (*env)->NewStringUTF(env, "ERROR: Invalid image index");
    }

    const char *rawName = wimlib_get_image_name(wim, imageIndex);
    const char *rawDescription =
            wimlib_get_image_description(wim, imageIndex);

    const char *fileCount =
            wimlib_get_image_property(wim, imageIndex, "FILECOUNT");
    const char *dirCount =
            wimlib_get_image_property(wim, imageIndex, "DIRCOUNT");
    const char *totalBytes =
            wimlib_get_image_property(wim, imageIndex, "TOTALBYTES");

    char name[512];
    char description[1024];
    char files[64];
    char directories[64];
    char bytes[64];

    copy_safe_field(name, sizeof(name), rawName);
    copy_safe_field(description, sizeof(description), rawDescription);
    copy_safe_field(files, sizeof(files), fileCount);
    copy_safe_field(directories, sizeof(directories), dirCount);
    copy_safe_field(bytes, sizeof(bytes), totalBytes);

    char result[4096];

    snprintf(result, sizeof(result),
             "IMAGE DETAILS\n"
             "Index: %d\n"
             "Name: %s\n"
             "Description: %s\n"
             "Files: %s\n"
             "Directories: %s\n"
             "Total bytes: %s",
             imageIndex,
             name,
             description,
             files[0] ? files : "Unavailable",
             directories[0] ? directories : "Unavailable",
             bytes[0] ? bytes : "Unavailable");

    wimlib_free(wim);

    return (*env)->NewStringUTF(env, result);
}

/*
 * Read-only directory browser JNI.
 * Lists only the direct children of the requested image path.
 */
struct browser_list_context {
    char *buffer;
    size_t length;
    size_t capacity;
    unsigned int count;
    int truncated;
    int failed;
};

#define BROWSER_MAX_ENTRIES 5000
#define BROWSER_MAX_BYTES (4U * 1024U * 1024U)

static int browser_append(struct browser_list_context *ctx,
                          const char *line, size_t line_length)
{
    if (line_length > BROWSER_MAX_BYTES ||
        ctx->length > BROWSER_MAX_BYTES - line_length) {
        ctx->truncated = 1;
        return 1;
    }

    size_t needed = ctx->length + line_length + 1;
    if (needed > ctx->capacity) {
        size_t new_capacity = ctx->capacity ? ctx->capacity : 4096;
        while (new_capacity < needed) {
            if (new_capacity >= BROWSER_MAX_BYTES) {
                new_capacity = BROWSER_MAX_BYTES + 1;
                break;
            }
            new_capacity *= 2;
        }

        char *new_buffer = realloc(ctx->buffer, new_capacity);
        if (new_buffer == NULL) {
            ctx->failed = 1;
            return 1;
        }

        ctx->buffer = new_buffer;
        ctx->capacity = new_capacity;
    }

    memcpy(ctx->buffer + ctx->length, line, line_length);
    ctx->length += line_length;
    ctx->buffer[ctx->length] = '\0';
    return 0;
}

static int browser_dir_callback(const struct wimlib_dir_entry *entry,
                                void *user_ctx)
{
    struct browser_list_context *ctx = user_ctx;

    if (ctx->count >= BROWSER_MAX_ENTRIES) {
        ctx->truncated = 1;
        return 1;
    }

    char name[1024];
    copy_safe_field(name, sizeof(name), entry->filename);

    int is_directory =
            (entry->attributes & WIMLIB_FILE_ATTRIBUTE_DIRECTORY) != 0;

    uint64_t size = 0;
    if (!is_directory)
        size = entry->streams[0].resource.uncompressed_size;

    char line[1400];
    int n = snprintf(line, sizeof(line),
                     "ENTRY|%c|%llu|%08X|%s\n",
                     is_directory ? 'D' : 'F',
                     (unsigned long long)size,
                     entry->attributes,
                     name);

    if (n < 0 || (size_t)n >= sizeof(line)) {
        ctx->failed = 1;
        return 1;
    }

    if (ctx->length + (size_t)n > BROWSER_MAX_BYTES - 128U) {
        ctx->truncated = 1;
        return 1;
    }

    if (browser_append(ctx, line, (size_t)n) != 0)
        return 1;

    ctx->count++;
    return 0;
}

JNIEXPORT jstring JNICALL
Java_com_example_wiminspector_WimBrowserActivity_nativeListDirectory(
        JNIEnv *env,
        jobject thiz,
        jstring javaPath,
        jint imageIndex,
        jstring javaDirectory)
{
    (void)thiz;

    if (javaPath == NULL || javaDirectory == NULL || imageIndex < 1)
        return (*env)->NewStringUTF(env, "ERROR|Invalid browser arguments");

    const char *path = (*env)->GetStringUTFChars(env, javaPath, NULL);
    if (path == NULL)
        return (*env)->NewStringUTF(env, "ERROR|Cannot read WIM path");

    const char *directory =
            (*env)->GetStringUTFChars(env, javaDirectory, NULL);
    if (directory == NULL) {
        (*env)->ReleaseStringUTFChars(env, javaPath, path);
        return (*env)->NewStringUTF(env, "ERROR|Cannot read directory path");
    }

    WIMStruct *wim = NULL;
    int ret = wimlib_open_wim(path, 0, &wim);

    (*env)->ReleaseStringUTFChars(env, javaPath, path);

    if (ret != 0) {
        (*env)->ReleaseStringUTFChars(env, javaDirectory, directory);
        char message[128];
        snprintf(message, sizeof(message), "ERROR|Cannot open WIM (code %d)", ret);
        return (*env)->NewStringUTF(env, message);
    }

    struct wimlib_wim_info info;
    ret = wimlib_get_wim_info(wim, &info);

    if (ret != 0 || imageIndex > (jint)info.image_count) {
        (*env)->ReleaseStringUTFChars(env, javaDirectory, directory);
        wimlib_free(wim);
        return (*env)->NewStringUTF(env, "ERROR|Invalid image index");
    }

    struct browser_list_context ctx;
    memset(&ctx, 0, sizeof(ctx));

    ret = wimlib_iterate_dir_tree(
            wim,
            imageIndex,
            directory,
            WIMLIB_ITERATE_DIR_TREE_FLAG_CHILDREN,
            browser_dir_callback,
            &ctx
    );

    (*env)->ReleaseStringUTFChars(env, javaDirectory, directory);
    wimlib_free(wim);

    if (ctx.failed) {
        free(ctx.buffer);
        return (*env)->NewStringUTF(env, "ERROR|Not enough memory to list this directory");
    }

    if (ret != 0 && !ctx.truncated) {
        free(ctx.buffer);
        char message[128];
        snprintf(message, sizeof(message),
                 "ERROR|Directory listing failed (wimlib code %d)", ret);
        return (*env)->NewStringUTF(env, message);
    }

    if (ctx.buffer == NULL) {
        ctx.buffer = calloc(1, 1);
        if (ctx.buffer == NULL)
            return (*env)->NewStringUTF(env, "ERROR|Out of memory");
    }

    if (ctx.truncated) {
        const char *notice = "TRUNCATED|Directory listing limit reached\n";
        browser_append(&ctx, notice, strlen(notice));
    }

    if (ctx.length == 0) {
        free(ctx.buffer);
        return (*env)->NewStringUTF(env, "EMPTY\n");
    }

    jstring result = (*env)->NewStringUTF(env, ctx.buffer);
    free(ctx.buffer);
    return result;
}


/*
 * Extract one file from a selected WIM image.
 * The destination directory must already exist.
 * The extracted file is placed directly inside that directory.
 */
JNIEXPORT jstring JNICALL
Java_com_example_wiminspector_WimBrowserActivity_nativeExtractFile(
        JNIEnv *env,
        jobject thiz,
        jstring javaWimPath,
        jint imageIndex,
        jstring javaImagePath,
        jstring javaDestination)
{
    (void)thiz;

    if (javaWimPath == NULL || javaImagePath == NULL ||
        javaDestination == NULL || imageIndex < 1) {
        return (*env)->NewStringUTF(env, "ERROR|Invalid extraction arguments");
    }

    const char *wimPath =
            (*env)->GetStringUTFChars(env, javaWimPath, NULL);
    if (wimPath == NULL)
        return (*env)->NewStringUTF(env, "ERROR|Cannot read WIM path");

    const char *imagePath =
            (*env)->GetStringUTFChars(env, javaImagePath, NULL);
    if (imagePath == NULL) {
        (*env)->ReleaseStringUTFChars(env, javaWimPath, wimPath);
        return (*env)->NewStringUTF(env, "ERROR|Cannot read image path");
    }

    const char *destination =
            (*env)->GetStringUTFChars(env, javaDestination, NULL);
    if (destination == NULL) {
        (*env)->ReleaseStringUTFChars(env, javaWimPath, wimPath);
        (*env)->ReleaseStringUTFChars(env, javaImagePath, imagePath);
        return (*env)->NewStringUTF(env, "ERROR|Cannot read destination");
    }

    WIMStruct *wim = NULL;
    int ret = wimlib_open_wim(wimPath, 0, &wim);

    (*env)->ReleaseStringUTFChars(env, javaWimPath, wimPath);

    if (ret != 0) {
        (*env)->ReleaseStringUTFChars(env, javaImagePath, imagePath);
        (*env)->ReleaseStringUTFChars(env, javaDestination, destination);

        char error[256];
        snprintf(error, sizeof(error),
                 "ERROR|Cannot open WIM (code %d)", ret);
        return (*env)->NewStringUTF(env, error);
    }

    struct wimlib_wim_info info;
    ret = wimlib_get_wim_info(wim, &info);

    if (ret != 0 || imageIndex > (jint)info.image_count) {
        wimlib_free(wim);
        (*env)->ReleaseStringUTFChars(env, javaImagePath, imagePath);
        (*env)->ReleaseStringUTFChars(env, javaDestination, destination);
        return (*env)->NewStringUTF(env, "ERROR|Invalid image index");
    }

    const wimlib_tchar *paths[1];
    paths[0] = imagePath;

    ret = wimlib_extract_paths(
            wim,
            imageIndex,
            destination,
            paths,
            1,
            WIMLIB_EXTRACT_FLAG_NO_PRESERVE_DIR_STRUCTURE |
            WIMLIB_EXTRACT_FLAG_NO_ACLS |
            WIMLIB_EXTRACT_FLAG_NO_ATTRIBUTES
    );

    wimlib_free(wim);

    (*env)->ReleaseStringUTFChars(env, javaImagePath, imagePath);
    (*env)->ReleaseStringUTFChars(env, javaDestination, destination);

    if (ret != 0) {
        const char *description = wimlib_get_error_string(ret);
        char error[512];

        snprintf(error, sizeof(error), "ERROR|Extraction failed (%d): %s",
                 ret, description ? description : "Unknown error");

        return (*env)->NewStringUTF(env, error);
    }

    return (*env)->NewStringUTF(env, "OK");
}
