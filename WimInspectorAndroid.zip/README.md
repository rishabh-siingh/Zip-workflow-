# WIM Inspector for Android — starter project

This is Milestone 1 of a standalone Android WIM inspector.

## Current implementation
- Native Android Java app with Material 3 Views.
- Android Storage Access Framework file picker.
- Accepts `.wim`, `.esd`, and `.swm` filename extensions.
- Displays the selected filename and reported size.
- Does not request broad storage permissions or require root/Termux.

## Important limitation
The wimlib native engine is **not included in this starter ZIP**. Therefore this milestone does not parse WIM metadata, list image indexes, browse image files, or extract content yet. The Inspect button is intentionally disabled rather than pretending that inspection succeeded.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK Platform 36 installed, then sync Gradle and build the `app` debug variant.

## Planned native integration
The next milestone adds:
- wimlib 1.14.5 source/library built for Android ABIs using the Android NDK.
- JNI wrapper for open/close, image count, WIM metadata, directory iteration and extraction.
- A seekable local-file bridge for SAF `content://` URIs (or a controlled cache copy when required).
- Background execution and progress/cancellation for large images.

## Suggested first ABI
Start with `arm64-v8a`, which is the primary ABI for most current Android phones. Add `armeabi-v7a` only if 32-bit device support is required.

## References
- wimlib C API: https://wimlib.net/apidoc/
- wimlib source/releases: https://wimlib.net/
- Android NDK + CMake: https://developer.android.com/studio/projects/configure-cmake
